@echo off
setlocal enabledelayedexpansion
title BeamStick Helper

set "PACKAGE=com.example.beamsticklauncher"
set "ADB_BIN=%~dp0adb.exe"

if not exist "%ADB_BIN%" (
    echo [FEHLER / ERROR] adb.exe wurde im Skript-Ordner nicht gefunden!
    echo Bitte stelle sicher, dass adb.exe, AdbWinApi.dll und AdbWinUsbApi.dll im selben Verzeichnis liegen.
    echo.
    pause
    exit /b 1
)

:: Ermittle Windows-Anzeigesprache (de-* -> DE, alle anderen -> EN)
for /f "tokens=*" %%a in ('powershell -NoProfile -Command "(Get-UICulture).TwoLetterISOLanguageName"') do set WIN_LANG=%%a

if /i "%WIN_LANG%"=="de" (
    set "MSG_HEADER========================================================="
    set "MSG_TITLE=      BeamStick Helper - All-in-One Verwaltung"
    set "MSG_STEP1=[1/6] Pruefe ADB-Verbindung zum Beamer..."
    set "MSG_ERR_NO_DEV=[FEHLER] Kein Geraet verbunden oder autorisiert!"
    set "MSG_ERR_NO_DEV_SUB=Bitte USB-/WLAN-Verbindung pruefen und USB-Debugging am Beamer erlauben."
    set "MSG_DEV_OK=      Geraet gefunden: "
    set "MSG_STEP2=[2/6] Installationsstatus auf dem Beamer..."
    set "MSG_APP_FOUND=      BeamStick ist auf dem Beamer installiert."
    set "MSG_MENU_TITLE=Waehle eine Aktion:"
    set "MSG_MENU_OPT1=[1] Nur Autostart- und Speicherrechte dauerhaft patchen"
    set "MSG_MENU_OPT2=[2] Aktualisieren / Drueberinstallieren (Daten behalten)"
    set "MSG_MENU_OPT3=[3] Reinstall: Sauber neu installieren (Vorher deinstallieren)"
    set "MSG_MENU_OPT4=[4] Uninstall: BeamStick vollstaendig entfernen"
    set "MSG_MENU_PROMPT=Deine Auswahl (1/2/3/4) [Standard: 1]: "
    set "MSG_APP_NOT_FOUND=      BeamStick ist noch nicht installiert. Starte Erstinstallation..."
    set "MSG_NO_APK=[FEHLER] Keine .apk-Datei im selben Ordner gefunden!"
    set "MSG_NO_APK_SUB=Bitte lege deine .apk-Datei direkt neben diese Batch-Datei."
    set "MSG_UNINSTALLING=      Deinstalliere bisherige Version..."
    set "MSG_UNINSTALL_OK=      App erfolgreich deinstalliert."
    set "MSG_INSTALLING=      Installiere APK: "
    set "MSG_INSTALL_OK=      Installation erfolgreich abgeschlossen."
    set "MSG_STEP3=[3/6] Gewaehre 'Ueber anderen Apps einblenden' (SYSTEM_ALERT_WINDOW)..."
    set "MSG_WARN_OVERLAY=[WARNUNG] SYSTEM_ALERT_WINDOW konnte nicht auf 'allow' gesetzt werden."
    set "MSG_OK_OVERLAY=      SYSTEM_ALERT_WINDOW erfolgreich auf 'allow' gesetzt."
    set "MSG_STEP4=[4/6] Verankere Speicher- und Systemrechte dauerhaft ueber UID und Flags..."
    set "MSG_OK_PERMS=      UID ermittelt, Auto-Revoke deaktiviert, All-Files-Access und Flags fixiert."
    set "MSG_STEP5=[5/6] Deaktiviere Energiesparmodus (Doze-Whitelist)..."
    set "MSG_OK_DOZE=      Doze-Whitelist-Eintrag gesetzt."
    set "MSG_STEP6=[6/6] Beende Stopped-State und synchronisiere Flash-Speicher..."
    set "MSG_OK_INIT=      App initialisiert, Hintergrund-Flags aktiv und Cache gesynct."
    set "MSG_FOOTER=      Vorgang erfolgreich abgeschlossen!"
    set "MSG_PROMPT_REBOOT=Moechtest du den Beamer jetzt neu starten, um den Autostart zu testen? (J/N): "
    set "MSG_REBOOTING=Starte Beamer neu..."
    set "MSG_NO_REBOOT=Beamer wurde nicht neu gestartet."
) else (
    set "MSG_HEADER========================================================="
    set "MSG_TITLE=      BeamStick Helper - All-in-One Management"
    set "MSG_STEP1=[1/6] Checking ADB connection to projector..."
    set "MSG_ERR_NO_DEV=[ERROR] No device connected or authorized!"
    set "MSG_ERR_NO_DEV_SUB=Please check USB/Wi-Fi connection and allow USB debugging on the projector."
    set "MSG_DEV_OK=      Device detected: "
    set "MSG_STEP2=[2/6] Checking installation status..."
    set "MSG_APP_FOUND=      BeamStick is currently installed on the projector."
    set "MSG_MENU_TITLE=Choose an action:"
    set "MSG_MENU_OPT1=[1] Patch autostart and storage permissions permanently"
    set "MSG_MENU_OPT2=[2] Update / Install over existing (Keep settings)"
    set "MSG_MENU_OPT3=[3] Reinstall: Clean reinstall (Uninstall first)"
    set "MSG_MENU_OPT4=[4] Uninstall: Remove BeamStick completely"
    set "MSG_MENU_PROMPT=Select (1/2/3/4) [Default: 1]: "
    set "MSG_APP_NOT_FOUND=      BeamStick is not installed yet. Starting fresh installation..."
    set "MSG_NO_APK=[ERROR] No .apk file found in this directory!"
    set "MSG_NO_APK_SUB=Please place your .apk file next to this batch file."
    set "MSG_UNINSTALLING=      Uninstalling existing version..."
    set "MSG_UNINSTALL_OK=      App uninstalled successfully."
    set "MSG_INSTALLING=      Installing APK: "
    set "MSG_INSTALL_OK=      Installation completed successfully."
    set "MSG_STEP3=[3/6] Granting 'Display over other apps' (SYSTEM_ALERT_WINDOW)..."
    set "MSG_WARN_OVERLAY=[WARNING] Failed to set SYSTEM_ALERT_WINDOW to 'allow'."
    set "MSG_OK_OVERLAY=      SYSTEM_ALERT_WINDOW successfully set to 'allow'."
    set "MSG_STEP4=[4/6] Setting permanent storage and system rights via UID and Flags..."
    set "MSG_OK_PERMS=      UID resolved, auto-revoke disabled, all-files access and flags locked."
    set "MSG_STEP5=[5/6] Disabling battery optimization (Doze whitelist)..."
    set "MSG_OK_DOZE=      Doze whitelist entry configured."
    set "MSG_STEP6=[6/6] Lifting stopped state and syncing flash storage..."
    set "MSG_OK_INIT=      App initialized, background flags active and storage synced."
    set "MSG_FOOTER=      Process completed successfully!"
    set "MSG_PROMPT_REBOOT=Do you want to reboot the projector now to test autostart? (Y/N): "
    set "MSG_REBOOTING=Rebooting projector..."
    set "MSG_NO_REBOOT=Projector was not rebooted."
)

echo %MSG_HEADER%
echo %MSG_TITLE%
echo %MSG_HEADER%
echo.

:: 1. ADB Geraet sauber ueber Zwischendatei ermitteln (Pfadsicher)
echo %MSG_STEP1%
set "TEMP_DEV_FILE=%TEMP%\adb_devs_%RANDOM%.txt"
"%ADB_BIN%" devices > "%TEMP_DEV_FILE%" 2>nul

set "TARGET_DEVICE="
for /f "tokens=1,2" %%A in ('type "%TEMP_DEV_FILE%"') do (
    if "%%B"=="device" (
        if not defined TARGET_DEVICE (
            set "TARGET_DEVICE=%%A"
        )
    )
)
if exist "%TEMP_DEV_FILE%" del "%TEMP_DEV_FILE%"

if not defined TARGET_DEVICE (
    echo.
    echo %MSG_ERR_NO_DEV%
    echo %MSG_ERR_NO_DEV_SUB%
    echo.
    pause
    exit /b 1
)
echo %MSG_DEV_OK%!TARGET_DEVICE!
echo.

:: 2. Status ermitteln
echo %MSG_STEP2%
set "USER_CHOICE=1"
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm list packages | findstr /i "%PACKAGE%" >nul
if %errorlevel% neq 0 goto do_fresh_install

echo %MSG_APP_FOUND%
echo.
echo %MSG_MENU_TITLE%
echo   %MSG_MENU_OPT1%
echo   %MSG_MENU_OPT2%
echo   %MSG_MENU_OPT3%
echo   %MSG_MENU_OPT4%
echo.
set /p USER_CHOICE="%MSG_MENU_PROMPT%"
goto process_choice

:do_fresh_install
echo %MSG_APP_NOT_FOUND%
set "USER_CHOICE=FRESH"

:process_choice
echo.

:: --- [OPTION 4] UNINSTALL ---
if "%USER_CHOICE%"=="4" (
    echo %MSG_UNINSTALLING%
    "%ADB_BIN%" -s !TARGET_DEVICE! uninstall %PACKAGE%
    echo %MSG_UNINSTALL_OK%
    goto finish_script
)

:: --- [OPTION 3] REINSTALL: VORAB DEINSTALLIEREN ---
if "%USER_CHOICE%"=="3" (
    echo %MSG_UNINSTALLING%
    "%ADB_BIN%" -s !TARGET_DEVICE! uninstall %PACKAGE% >nul 2>&1
    echo %MSG_UNINSTALL_OK%
    echo.
)

:: --- APK INSTALLATION (Fuer FRESH, 2 und 3) ---
if "%USER_CHOICE%"=="FRESH" goto do_install
if "%USER_CHOICE%"=="2" goto do_install
if "%USER_CHOICE%"=="3" goto do_install
goto apply_permissions

:do_install
set "LOCAL_APK="
for %%F in ("%~dp0*.apk") do (
    if not defined LOCAL_APK set "LOCAL_APK=%%~fF"
)

if not defined LOCAL_APK (
    echo.
    echo %MSG_NO_APK%
    echo %MSG_NO_APK_SUB%
    echo.
    goto finish_script
)

echo %MSG_INSTALLING%!LOCAL_APK!
"%ADB_BIN%" -s !TARGET_DEVICE! install -r -d "!LOCAL_APK!"
if %errorlevel% equ 0 (
    echo %MSG_INSTALL_OK%
) else (
    echo [WARNUNG / WARNING] Installation meldete einen Fehlercode.
)
echo.

:apply_permissions
:: UID dynamisch ueber Zwischendatei ermitteln (verhindert Pfadfehler bei Leerzeichen)
set "TEMP_UID_FILE=%TEMP%\adb_uid_%RANDOM%.txt"
"%ADB_BIN%" -s !TARGET_DEVICE! shell dumpsys package %PACKAGE% > "%TEMP_UID_FILE%" 2>nul

set "APP_UID="
for /f "tokens=2 delims==" %%u in ('type "%TEMP_UID_FILE%" ^| findstr /i "userId="') do (
    if not defined APP_UID (
        for /f "tokens=1" %%x in ("%%u") do set "APP_UID=%%x"
    )
)
if exist "%TEMP_UID_FILE%" del "%TEMP_UID_FILE%"

:: 3. Overlay-Rechte (SYSTEM_ALERT_WINDOW)
echo %MSG_STEP3%
"%ADB_BIN%" -s !TARGET_DEVICE! shell appops set %PACKAGE% SYSTEM_ALERT_WINDOW allow >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell appops set %PACKAGE% 24 allow >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm grant %PACKAGE% android.permission.SYSTEM_ALERT_WINDOW >nul 2>&1

if defined APP_UID (
    "%ADB_BIN%" -s !TARGET_DEVICE! shell cmd appops set --uid !APP_UID! SYSTEM_ALERT_WINDOW allow >nul 2>&1
    "%ADB_BIN%" -s !TARGET_DEVICE! shell cmd appops set --uid !APP_UID! 24 allow >nul 2>&1
)

"%ADB_BIN%" -s !TARGET_DEVICE! shell appops get %PACKAGE% SYSTEM_ALERT_WINDOW | findstr /i "allow" >nul
if %errorlevel% neq 0 (
    echo %MSG_WARN_OVERLAY%
) else (
    echo %MSG_OK_OVERLAY%
)
echo.

:: 4. Auto-Revoke Schutz & Speicherberechtigungen DAUERHAFT FIXIEREN
echo %MSG_STEP4%

:: Paket- und UID-Zuweisung fuer Speicher-Vollzugriff
"%ADB_BIN%" -s !TARGET_DEVICE! shell appops set %PACKAGE% MANAGE_EXTERNAL_STORAGE allow >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell appops set %PACKAGE% 92 allow >nul 2>&1

if defined APP_UID (
    "%ADB_BIN%" -s !TARGET_DEVICE! shell cmd appops set --uid !APP_UID! MANAGE_EXTERNAL_STORAGE allow >nul 2>&1
    "%ADB_BIN%" -s !TARGET_DEVICE! shell cmd appops set --uid !APP_UID! 92 allow >nul 2>&1
)

:: Klassische Permissions vergeben
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm grant %PACKAGE% android.permission.READ_EXTERNAL_STORAGE >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm grant %PACKAGE% android.permission.WRITE_EXTERNAL_STORAGE >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm grant %PACKAGE% android.permission.READ_MEDIA_VIDEO >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm grant %PACKAGE% android.permission.READ_MEDIA_AUDIO >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm grant %PACKAGE% android.permission.READ_MEDIA_IMAGES >nul 2>&1

:: WICHTIG: Berechtigungs-Flags auf USER_SET und USER_FIXED sperren gegen System-Reset
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm set-permission-flags %PACKAGE% android.permission.MANAGE_EXTERNAL_STORAGE user-set >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm set-permission-flags %PACKAGE% android.permission.MANAGE_EXTERNAL_STORAGE user-fixed >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm set-permission-flags %PACKAGE% android.permission.READ_EXTERNAL_STORAGE user-set >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm set-permission-flags %PACKAGE% android.permission.READ_EXTERNAL_STORAGE user-fixed >nul 2>&1

:: Auto-Revoke Schutz aktivieren
"%ADB_BIN%" -s !TARGET_DEVICE! shell pm set-auto-revoke %PACKAGE% false >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell appops set %PACKAGE% AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >nul 2>&1

if defined APP_UID (
    "%ADB_BIN%" -s !TARGET_DEVICE! shell cmd appops set --uid !APP_UID! AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >nul 2>&1
)
echo %MSG_OK_PERMS%
echo.

:: 5. Doze-Whitelist
echo %MSG_STEP5%
"%ADB_BIN%" -s !TARGET_DEVICE! shell dumpsys deviceidle whitelist +%PACKAGE% >nul 2>&1
echo %MSG_OK_DOZE%
echo.

:: 6. Stopped-State aufheben und Flash synchronisieren
echo %MSG_STEP6%
"%ADB_BIN%" -s !TARGET_DEVICE! shell am start -n %PACKAGE%/.MainActivity >nul 2>&1
timeout /t 3 /nobreak >nul
"%ADB_BIN%" -s !TARGET_DEVICE! shell input keyevent 3 >nul 2>&1
"%ADB_BIN%" -s !TARGET_DEVICE! shell sync >nul 2>&1
echo %MSG_OK_INIT%
echo.

:: 7. Reboot-Abfrage
set "DO_REBOOT="
set /p DO_REBOOT="%MSG_PROMPT_REBOOT%"
if /i "%DO_REBOOT%"=="j" (
    echo %MSG_REBOOTING%
    "%ADB_BIN%" -s !TARGET_DEVICE! reboot
) else if /i "%DO_REBOOT%"=="y" (
    echo %MSG_REBOOTING%
    "%ADB_BIN%" -s !TARGET_DEVICE! reboot
) else (
    echo %MSG_NO_REBOOT%
)

:finish_script
echo.
echo %MSG_HEADER%
echo %MSG_FOOTER%
echo %MSG_HEADER%
echo.
pause